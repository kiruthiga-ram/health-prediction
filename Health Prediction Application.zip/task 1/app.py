from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
import os
import re
import requests
import json
from dotenv import load_dotenv

load_dotenv()  # loads GEMINI_API_KEY from .env automatically

app = Flask(__name__)
app.config['SECRET_KEY'] = 'health-app-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///health_records.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ── Model ──────────────────────────────────────────────────────────────────────

class Patient(db.Model):
    id            = db.Column(db.Integer, primary_key=True)
    full_name     = db.Column(db.String(150), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    email         = db.Column(db.String(200), nullable=False, unique=True)
    glucose       = db.Column(db.Float, nullable=False)
    haemoglobin   = db.Column(db.Float, nullable=False)
    cholesterol   = db.Column(db.Float, nullable=False)
    remarks       = db.Column(db.Text, nullable=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at    = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id':            self.id,
            'full_name':     self.full_name,
            'date_of_birth': self.date_of_birth.strftime('%Y-%m-%d'),
            'email':         self.email,
            'glucose':       self.glucose,
            'haemoglobin':   self.haemoglobin,
            'cholesterol':   self.cholesterol,
            'remarks':       self.remarks or '',
            'created_at':    self.created_at.strftime('%Y-%m-%d %H:%M'),
            'updated_at':    self.updated_at.strftime('%Y-%m-%d %H:%M'),
        }

# ── Validation helpers ─────────────────────────────────────────────────────────

def validate_email(email: str) -> bool:
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return bool(re.match(pattern, email))

def validate_dob(dob_str: str):
    """Return a date object or raise ValueError."""
    try:
        dob = datetime.strptime(dob_str, '%Y-%m-%d').date()
    except ValueError:
        raise ValueError('Date of birth must be in YYYY-MM-DD format.')
    if dob >= date.today():
        raise ValueError('Date of birth cannot be today or a future date.')
    return dob

def validate_numeric(value, name: str, low: float, high: float) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise ValueError(f'{name} must be a numeric value.')
    if v < low or v > high:
        raise ValueError(f'{name} must be between {low} and {high}.')
    return v

def validate_patient_data(data: dict, update: bool = False):
    """Validate all fields. Returns cleaned dict or raises ValueError."""
    errors = []

    full_name = (data.get('full_name') or '').strip()
    if not full_name:
        errors.append('Full name is required.')
    elif len(full_name) < 2:
        errors.append('Full name must be at least 2 characters.')

    dob = None
    dob_str = (data.get('date_of_birth') or '').strip()
    if not dob_str:
        errors.append('Date of birth is required.')
    else:
        try:
            dob = validate_dob(dob_str)
        except ValueError as e:
            errors.append(str(e))

    email = (data.get('email') or '').strip().lower()
    if not email:
        errors.append('Email address is required.')
    elif not validate_email(email):
        errors.append('Email address format is invalid.')

    glucose = haemoglobin = cholesterol = None
    try:
        glucose = validate_numeric(data.get('glucose'), 'Glucose', 0, 1000)
    except ValueError as e:
        errors.append(str(e))
    try:
        haemoglobin = validate_numeric(data.get('haemoglobin'), 'Haemoglobin', 0, 30)
    except ValueError as e:
        errors.append(str(e))
    try:
        cholesterol = validate_numeric(data.get('cholesterol'), 'Cholesterol', 0, 1000)
    except ValueError as e:
        errors.append(str(e))

    if errors:
        raise ValueError(' | '.join(errors))

    return {
        'full_name':     full_name,
        'date_of_birth': dob,
        'email':         email,
        'glucose':       glucose,
        'haemoglobin':   haemoglobin,
        'cholesterol':   cholesterol,
    }

# ── AI / Health prediction ─────────────────────────────────────────────────────

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')

def get_health_prediction(patient: dict) -> str:
    """
    Call Google Gemini (gemini-1.5-flash) to generate a health risk assessment.
    Falls back to a rule-based assessment if the API key is missing or the call fails.
    """
    dob = patient['date_of_birth']
    if isinstance(dob, str):
        dob = datetime.strptime(dob, '%Y-%m-%d').date()
    age = (date.today() - dob).days // 365

    prompt = f"""You are a clinical health assistant. Based on the following blood test results,
provide a concise health risk assessment (2-4 sentences). Mention any likely conditions or risks,
and give a brief recommendation. Do NOT use markdown formatting — plain text only.

Patient details:
- Age: {age} years
- Glucose: {patient['glucose']} mg/dL  (normal fasting: 70–99 mg/dL)
- Haemoglobin: {patient['haemoglobin']} g/dL  (normal: 12–17.5 g/dL)
- Cholesterol: {patient['cholesterol']} mg/dL  (desirable: <200 mg/dL)

Provide the assessment now:"""

    if GEMINI_API_KEY:
        try:
            url = (
                'https://generativelanguage.googleapis.com/v1beta/models/'
                f'gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}'
            )
            payload = {
                'contents': [{'parts': [{'text': prompt}]}],
                'generationConfig': {'temperature': 0.4, 'maxOutputTokens': 256},
            }
            resp = requests.post(url, json=payload, timeout=15)
            resp.raise_for_status()
            result = resp.json()
            text = (
                result['candidates'][0]['content']['parts'][0]['text']
                .strip()
            )
            return text
        except Exception as e:
            print(f'[Gemini API error] {e}')
            # fall through to rule-based

    # ── Rule-based fallback ────────────────────────────────────────────────────
    return rule_based_assessment(patient['glucose'], patient['haemoglobin'],
                                  patient['cholesterol'], age)


def rule_based_assessment(glucose: float, haemoglobin: float,
                           cholesterol: float, age: int) -> str:
    findings = []
    recommendations = []

    # Glucose
    if glucose < 70:
        findings.append('hypoglycaemia (low blood sugar)')
        recommendations.append('increase carbohydrate intake and consult a physician')
    elif 100 <= glucose < 126:
        findings.append('pre-diabetes (impaired fasting glucose)')
        recommendations.append('adopt a low-sugar diet and increase physical activity')
    elif glucose >= 126:
        findings.append('possible diabetes mellitus (high fasting glucose)')
        recommendations.append('seek immediate medical evaluation for diabetes management')

    # Haemoglobin
    normal_low = 12.0 if age < 18 else (13.5 if age >= 18 else 12.0)
    if haemoglobin < normal_low:
        findings.append('anaemia (low haemoglobin)')
        recommendations.append('consider iron-rich foods or supplementation and consult a doctor')
    elif haemoglobin > 17.5:
        findings.append('polycythaemia (elevated haemoglobin)')
        recommendations.append('consult a haematologist for further evaluation')

    # Cholesterol
    if 200 <= cholesterol < 240:
        findings.append('borderline high cholesterol')
        recommendations.append('reduce saturated fat intake and exercise regularly')
    elif cholesterol >= 240:
        findings.append('high cholesterol (hypercholesterolaemia)')
        recommendations.append('consult a physician regarding lipid-lowering therapy')

    if not findings:
        return (
            'All measured values are within normal reference ranges. '
            'The patient appears to be in good metabolic health. '
            'Continue maintaining a balanced diet and regular exercise. '
            'Routine annual check-ups are recommended.'
        )

    finding_str = ', '.join(findings)
    rec_str = '; '.join(recommendations)
    return (
        f'Blood test results indicate {finding_str}. '
        f'Recommendations: {rec_str}. '
        'Please consult a qualified healthcare professional for a full clinical evaluation.'
    )

# ── Routes ─────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

# --- CREATE ---
@app.route('/api/patients', methods=['POST'])
def create_patient():
    data = request.get_json(force=True)
    try:
        clean = validate_patient_data(data)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400

    # Duplicate email check
    if Patient.query.filter_by(email=clean['email']).first():
        return jsonify({'success': False, 'error': 'A patient with this email already exists.'}), 409

    # AI prediction
    remarks = get_health_prediction(clean)

    patient = Patient(
        full_name     = clean['full_name'],
        date_of_birth = clean['date_of_birth'],
        email         = clean['email'],
        glucose       = clean['glucose'],
        haemoglobin   = clean['haemoglobin'],
        cholesterol   = clean['cholesterol'],
        remarks       = remarks,
    )
    db.session.add(patient)
    db.session.commit()
    return jsonify({'success': True, 'patient': patient.to_dict()}), 201

# --- READ ALL ---
@app.route('/api/patients', methods=['GET'])
def get_patients():
    search = request.args.get('search', '').strip()
    query = Patient.query
    if search:
        like = f'%{search}%'
        query = query.filter(
            db.or_(
                Patient.full_name.ilike(like),
                Patient.email.ilike(like),
            )
        )
    patients = query.order_by(Patient.created_at.desc()).all()
    return jsonify({'success': True, 'patients': [p.to_dict() for p in patients]})

# --- READ ONE ---
@app.route('/api/patients/<int:patient_id>', methods=['GET'])
def get_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    return jsonify({'success': True, 'patient': patient.to_dict()})

# --- UPDATE ---
@app.route('/api/patients/<int:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    data = request.get_json(force=True)
    try:
        clean = validate_patient_data(data, update=True)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400

    # Duplicate email check (exclude self)
    existing = Patient.query.filter_by(email=clean['email']).first()
    if existing and existing.id != patient_id:
        return jsonify({'success': False, 'error': 'Another patient with this email already exists.'}), 409

    # Re-generate AI prediction
    remarks = get_health_prediction(clean)

    patient.full_name     = clean['full_name']
    patient.date_of_birth = clean['date_of_birth']
    patient.email         = clean['email']
    patient.glucose       = clean['glucose']
    patient.haemoglobin   = clean['haemoglobin']
    patient.cholesterol   = clean['cholesterol']
    patient.remarks       = remarks
    patient.updated_at    = datetime.utcnow()
    db.session.commit()
    return jsonify({'success': True, 'patient': patient.to_dict()})

# --- DELETE ---
@app.route('/api/patients/<int:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    db.session.delete(patient)
    db.session.commit()
    return jsonify({'success': True, 'message': 'Patient record deleted.'})

# ── Bootstrap DB ───────────────────────────────────────────────────────────────

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, port=5000)
