/* ── HealthPredict — Frontend Logic ──────────────────────────────────────── */

'use strict';

// ── Bootstrap modal instances ─────────────────────────────────────────────────
const patientModal  = new bootstrap.Modal(document.getElementById('patientModal'));
const remarksModal  = new bootstrap.Modal(document.getElementById('remarksModal'));
const deleteModal   = new bootstrap.Modal(document.getElementById('deleteModal'));

// ── State ─────────────────────────────────────────────────────────────────────
let editingId    = null;   // null = create mode, number = edit mode
let deleteTarget = null;   // { id, name }
let searchTimer  = null;

// ── DOM refs ──────────────────────────────────────────────────────────────────
const tableBody      = document.getElementById('tableBody');
const searchInput    = document.getElementById('searchInput');
const recordCount    = document.getElementById('recordCount');
const btnAddNew      = document.getElementById('btnAddNew');
const btnSave        = document.getElementById('btnSave');
const btnClearSearch = document.getElementById('btnClearSearch');
const btnConfirmDel  = document.getElementById('btnConfirmDelete');
const saveSpinner    = document.getElementById('saveSpinner');
const saveIcon       = document.getElementById('saveIcon');
const saveLabel      = document.getElementById('saveLabel');
const deleteSpinner  = document.getElementById('deleteSpinner');

// ── Utility: Toast ────────────────────────────────────────────────────────────
function showToast(message, type = 'success') {
  const icons = { success: 'bi-check-circle-fill', danger: 'bi-x-circle-fill',
                  warning: 'bi-exclamation-triangle-fill', info: 'bi-info-circle-fill' };
  const colours = { success: 'text-success', danger: 'text-danger',
                    warning: 'text-warning', info: 'text-primary' };
  const id = 'toast_' + Date.now();
  const html = `
    <div id="${id}" class="toast align-items-center border-0 shadow-sm" role="alert">
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center gap-2">
          <i class="bi ${icons[type]} ${colours[type]}"></i>
          <span>${message}</span>
        </div>
        <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>`;
  document.getElementById('toastContainer').insertAdjacentHTML('beforeend', html);
  const el = document.getElementById(id);
  const t  = new bootstrap.Toast(el, { delay: 4000 });
  t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}

// ── Utility: Blood value colour classification ────────────────────────────────
function glucoseClass(v) {
  if (v < 70 || v >= 126) return 'value-danger';
  if (v >= 100)           return 'value-warning';
  return 'value-normal';
}
function haemoglobinClass(v) {
  if (v < 12 || v > 17.5) return 'value-danger';
  return 'value-normal';
}
function cholesterolClass(v) {
  if (v >= 240) return 'value-danger';
  if (v >= 200) return 'value-warning';
  return 'value-normal';
}

// ── Utility: Age from DOB ─────────────────────────────────────────────────────
function calcAge(dobStr) {
  const dob   = new Date(dobStr);
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

// ── Render table ──────────────────────────────────────────────────────────────
function renderTable(patients) {
  if (!patients.length) {
    tableBody.innerHTML = `
      <tr><td colspan="9">
        <div class="empty-state">
          <i class="bi bi-clipboard2-pulse"></i>
          <p class="mb-0 fw-medium">No patient records found</p>
          <p class="small">Click <strong>Add Patient</strong> to get started.</p>
        </div>
      </td></tr>`;
    recordCount.textContent = '0 records';
    return;
  }

  recordCount.textContent = `${patients.length} record${patients.length !== 1 ? 's' : ''}`;

  tableBody.innerHTML = patients.map((p, i) => {
    const age     = calcAge(p.date_of_birth);
    const dob     = new Date(p.date_of_birth).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
    const remarks = p.remarks ? escapeHtml(p.remarks) : '<em class="text-muted">—</em>';
    const shortRemark = p.remarks
      ? escapeHtml(p.remarks.length > 80 ? p.remarks.slice(0, 80) + '…' : p.remarks)
      : '<em class="text-muted">—</em>';

    return `
      <tr data-id="${p.id}">
        <td class="ps-3 text-muted">${i + 1}</td>
        <td>
          <div class="fw-semibold">${escapeHtml(p.full_name)}</div>
          <div class="text-muted small">${age} yrs</div>
        </td>
        <td class="text-nowrap">${dob}</td>
        <td>
          <a href="mailto:${escapeHtml(p.email)}" class="text-decoration-none text-primary small">
            ${escapeHtml(p.email)}
          </a>
        </td>
        <td class="text-center">
          <span class="value-badge ${glucoseClass(p.glucose)}">${p.glucose}</span>
        </td>
        <td class="text-center">
          <span class="value-badge ${haemoglobinClass(p.haemoglobin)}">${p.haemoglobin}</span>
        </td>
        <td class="text-center">
          <span class="value-badge ${cholesterolClass(p.cholesterol)}">${p.cholesterol}</span>
        </td>
        <td>
          <span class="remarks-cell d-block" title="${remarks}">${shortRemark}</span>
          ${p.remarks ? `<button class="btn btn-link btn-sm p-0 text-primary small"
            onclick="viewRemarks(${p.id})">View full</button>` : ''}
        </td>
        <td class="text-center pe-3">
          <div class="d-flex gap-1 justify-content-center">
            <button class="btn btn-outline-primary btn-action" title="Edit"
              onclick="openEdit(${p.id})">
              <i class="bi bi-pencil-fill"></i>
            </button>
            <button class="btn btn-outline-danger btn-action" title="Delete"
              onclick="openDelete(${p.id}, '${escapeHtml(p.full_name)}')">
              <i class="bi bi-trash3-fill"></i>
            </button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ── Load patients ─────────────────────────────────────────────────────────────
async function loadPatients(search = '') {
  try {
    const url = search ? `/api/patients?search=${encodeURIComponent(search)}` : '/api/patients';
    const res  = await fetch(url);
    const data = await res.json();
    if (data.success) renderTable(data.patients);
  } catch (err) {
    showToast('Failed to load patient records.', 'danger');
  }
}

// ── Form helpers ──────────────────────────────────────────────────────────────
function clearForm() {
  ['fullName','dateOfBirth','email','glucose','haemoglobin','cholesterol'].forEach(id => {
    const el = document.getElementById(id);
    el.value = '';
    el.classList.remove('is-invalid', 'is-valid');
  });
  ['fullNameError','dobError','emailError','glucoseError','haemoglobinError','cholesterolError']
    .forEach(id => { document.getElementById(id).textContent = ''; });
}

function populateForm(p) {
  document.getElementById('fullName').value    = p.full_name;
  document.getElementById('dateOfBirth').value = p.date_of_birth;
  document.getElementById('email').value       = p.email;
  document.getElementById('glucose').value     = p.glucose;
  document.getElementById('haemoglobin').value = p.haemoglobin;
  document.getElementById('cholesterol').value = p.cholesterol;
}

function getFormData() {
  return {
    full_name:     document.getElementById('fullName').value.trim(),
    date_of_birth: document.getElementById('dateOfBirth').value,
    email:         document.getElementById('email').value.trim(),
    glucose:       document.getElementById('glucose').value,
    haemoglobin:   document.getElementById('haemoglobin').value,
    cholesterol:   document.getElementById('cholesterol').value,
  };
}

// ── Client-side validation (mirrors server) ───────────────────────────────────
function validateForm(data) {
  let valid = true;

  function setError(fieldId, errId, msg) {
    const el = document.getElementById(fieldId);
    const er = document.getElementById(errId);
    if (msg) {
      el.classList.add('is-invalid');
      el.classList.remove('is-valid');
      er.textContent = msg;
      valid = false;
    } else {
      el.classList.remove('is-invalid');
      el.classList.add('is-valid');
      er.textContent = '';
    }
  }

  // Full name
  if (!data.full_name || data.full_name.length < 2)
    setError('fullName', 'fullNameError', 'Full name must be at least 2 characters.');
  else
    setError('fullName', 'fullNameError', '');

  // DOB
  if (!data.date_of_birth) {
    setError('dateOfBirth', 'dobError', 'Date of birth is required.');
  } else {
    const dob = new Date(data.date_of_birth);
    if (dob >= new Date()) setError('dateOfBirth', 'dobError', 'Date of birth cannot be today or a future date.');
    else setError('dateOfBirth', 'dobError', '');
  }

  // Email
  const emailRe = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
  if (!data.email) setError('email', 'emailError', 'Email address is required.');
  else if (!emailRe.test(data.email)) setError('email', 'emailError', 'Invalid email address format.');
  else setError('email', 'emailError', '');

  // Numeric fields
  function checkNum(val, fieldId, errId, label, min, max) {
    const n = parseFloat(val);
    if (val === '' || isNaN(n)) setError(fieldId, errId, `${label} must be a numeric value.`);
    else if (n < min || n > max) setError(fieldId, errId, `${label} must be between ${min} and ${max}.`);
    else setError(fieldId, errId, '');
  }
  checkNum(data.glucose,     'glucose',     'glucoseError',     'Glucose',     0, 1000);
  checkNum(data.haemoglobin, 'haemoglobin', 'haemoglobinError', 'Haemoglobin', 0, 30);
  checkNum(data.cholesterol, 'cholesterol', 'cholesterolError', 'Cholesterol', 0, 1000);

  return valid;
}

// ── Save button state ─────────────────────────────────────────────────────────
function setSaving(on) {
  btnSave.disabled = on;
  saveSpinner.classList.toggle('d-none', !on);
  saveIcon.classList.toggle('d-none', on);
  saveLabel.textContent = on ? 'Analysing…' : (editingId ? 'Update & Predict' : 'Save & Predict');
}

// ── Open Add modal ────────────────────────────────────────────────────────────
btnAddNew.addEventListener('click', () => {
  editingId = null;
  clearForm();
  document.getElementById('modalTitle').innerHTML =
    '<i class="bi bi-person-plus-fill me-2"></i>Add New Patient';
  saveLabel.textContent = 'Save & Predict';
  patientModal.show();
});

// ── Open Edit modal ───────────────────────────────────────────────────────────
async function openEdit(id) {
  try {
    const res  = await fetch(`/api/patients/${id}`);
    const data = await res.json();
    if (!data.success) throw new Error();
    editingId = id;
    clearForm();
    populateForm(data.patient);
    document.getElementById('modalTitle').innerHTML =
      '<i class="bi bi-pencil-fill me-2"></i>Edit Patient Record';
    saveLabel.textContent = 'Update & Predict';
    patientModal.show();
  } catch {
    showToast('Could not load patient data.', 'danger');
  }
}

// ── Save (create or update) ───────────────────────────────────────────────────
btnSave.addEventListener('click', async () => {
  const data = getFormData();
  if (!validateForm(data)) return;

  setSaving(true);
  try {
    const url    = editingId ? `/api/patients/${editingId}` : '/api/patients';
    const method = editingId ? 'PUT' : 'POST';
    const res    = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();

    if (result.success) {
      patientModal.hide();
      showToast(editingId ? 'Patient record updated.' : 'Patient added successfully.', 'success');
      loadPatients(searchInput.value.trim());
    } else {
      showToast(result.error || 'An error occurred.', 'danger');
    }
  } catch {
    showToast('Network error. Please try again.', 'danger');
  } finally {
    setSaving(false);
  }
});

// ── View full remarks ─────────────────────────────────────────────────────────
async function viewRemarks(id) {
  try {
    const res  = await fetch(`/api/patients/${id}`);
    const data = await res.json();
    if (!data.success) throw new Error();
    document.getElementById('remarksPatientName').textContent = data.patient.full_name;
    document.getElementById('remarksText').textContent        = data.patient.remarks || 'No remarks available.';
    remarksModal.show();
  } catch {
    showToast('Could not load remarks.', 'danger');
  }
}

// ── Open Delete confirm ───────────────────────────────────────────────────────
function openDelete(id, name) {
  deleteTarget = { id, name };
  document.getElementById('deletePatientName').textContent = name;
  deleteModal.show();
}

// ── Confirm delete ────────────────────────────────────────────────────────────
btnConfirmDel.addEventListener('click', async () => {
  if (!deleteTarget) return;
  btnConfirmDel.disabled = true;
  deleteSpinner.classList.remove('d-none');
  try {
    const res    = await fetch(`/api/patients/${deleteTarget.id}`, { method: 'DELETE' });
    const result = await res.json();
    if (result.success) {
      deleteModal.hide();
      showToast(`"${deleteTarget.name}" has been deleted.`, 'info');
      loadPatients(searchInput.value.trim());
    } else {
      showToast('Delete failed.', 'danger');
    }
  } catch {
    showToast('Network error.', 'danger');
  } finally {
    btnConfirmDel.disabled = false;
    deleteSpinner.classList.add('d-none');
    deleteTarget = null;
  }
});

// ── Search ────────────────────────────────────────────────────────────────────
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadPatients(searchInput.value.trim()), 350);
});

btnClearSearch.addEventListener('click', () => {
  searchInput.value = '';
  loadPatients();
});

// ── Reset form validation state when modal closes ─────────────────────────────
document.getElementById('patientModal').addEventListener('hidden.bs.modal', () => {
  clearForm();
  setSaving(false);
});

// ── Set max date for DOB to yesterday ─────────────────────────────────────────
(function setMaxDob() {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  document.getElementById('dateOfBirth').max = yesterday.toISOString().split('T')[0];
})();

// ── Initial load ──────────────────────────────────────────────────────────────
loadPatients();
