import urllib.request, json

patients = [
    {
        "full_name": "James Okonkwo",
        "date_of_birth": "1978-04-12",
        "email": "james.okonkwo@email.com",
        "glucose": 132.0,
        "haemoglobin": 10.8,
        "cholesterol": 242.0
    },
    {
        "full_name": "Amara Nwosu",
        "date_of_birth": "1995-09-23",
        "email": "amara.nwosu@email.com",
        "glucose": 88.0,
        "haemoglobin": 14.2,
        "cholesterol": 175.0
    },
    {
        "full_name": "David Mensah",
        "date_of_birth": "1965-01-30",
        "email": "david.mensah@email.com",
        "glucose": 68.0,
        "haemoglobin": 13.0,
        "cholesterol": 210.0
    },
    {
        "full_name": "Fatima Al-Hassan",
        "date_of_birth": "1988-07-05",
        "email": "fatima.alhassan@email.com",
        "glucose": 105.0,
        "haemoglobin": 11.5,
        "cholesterol": 195.0
    },
    {
        "full_name": "Chidi Eze",
        "date_of_birth": "2000-11-18",
        "email": "chidi.eze@email.com",
        "glucose": 94.0,
        "haemoglobin": 15.8,
        "cholesterol": 158.0
    },
    {
        "full_name": "Ngozi Adeyemi",
        "date_of_birth": "1972-03-08",
        "email": "ngozi.adeyemi@email.com",
        "glucose": 148.0,
        "haemoglobin": 9.5,
        "cholesterol": 265.0
    },
    {
        "full_name": "Samuel Boateng",
        "date_of_birth": "1990-06-14",
        "email": "samuel.boateng@email.com",
        "glucose": 79.0,
        "haemoglobin": 16.1,
        "cholesterol": 188.0
    }
]

for p in patients:
    payload = json.dumps(p).encode()
    req = urllib.request.Request(
        "http://localhost:5000/api/patients",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        r = urllib.request.urlopen(req)
        data = json.loads(r.read())
        preview = data["patient"]["remarks"][:80]
        print(f"Added: {p['full_name']}")
        print(f"  Remarks: {preview}...")
    except urllib.error.HTTPError as e:
        body = json.loads(e.read())
        print(f"Skipped {p['full_name']}: {body.get('error', e)}")
    except Exception as e:
        print(f"Failed {p['full_name']}: {e}")

print("\nDone!")
