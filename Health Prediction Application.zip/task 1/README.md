# HealthPredict — AI-Powered Blood Test Health Assessment

A full-stack health prediction application built with **Python/Flask** (backend),
**SQLite** (persistent storage), and **Bootstrap 5** (frontend).

## Features

| Feature | Details |
|---|---|
| CRUD | Create, Read, Update, Delete patient records |
| Validation | Client-side + server-side (email format, DOB not future, numeric ranges) |
| Persistent Storage | SQLite via SQLAlchemy |
| AI Prediction | Google Gemini 1.5 Flash API → health risk assessment in Remarks |
| Fallback | Rule-based assessment when no API key is set |
| Search | Live search by name or email |
| Visual indicators | Colour-coded blood value badges (normal / warning / danger) |

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. (Optional) Set your Gemini API key
Get a free key at https://aistudio.google.com/app/apikey

**Windows (PowerShell):**
```powershell
$env:GEMINI_API_KEY = "your_key_here"
```

**Linux / macOS:**
```bash
export GEMINI_API_KEY="your_key_here"
```

### 3. Run the application
```bash
python app.py
```

Open your browser at **http://localhost:5000**

## Blood Test Reference Ranges

| Test | Normal Range | Unit |
|---|---|---|
| Glucose (fasting) | 70 – 99 | mg/dL |
| Haemoglobin | 12 – 17.5 | g/dL |
| Cholesterol | < 200 (desirable) | mg/dL |

## Project Structure

```
├── app.py               # Flask app, routes, AI integration, validation
├── requirements.txt
├── .env.example
├── templates/
│   └── index.html       # Single-page Bootstrap UI
├── static/
│   ├── css/style.css    # Custom styles
│   └── js/app.js        # Frontend logic (CRUD, validation, modals)
└── instance/
    └── health_records.db  # SQLite database (auto-created on first run)
```
